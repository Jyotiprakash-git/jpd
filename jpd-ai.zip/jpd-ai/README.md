# JPD.AI — Intelligent Multilingual Assistant

> The world's most honest, multilingual AI assistant. 45+ languages, real math engine, crisis detection, session memory, and more.

![JPD.AI](https://img.shields.io/badge/JPD.AI-v1.0.0-5b50f0?style=for-the-badge)
![React](https://img.shields.io/badge/React-18-61DAFB?style=for-the-badge&logo=react)
![Vite](https://img.shields.io/badge/Vite-5-646CFF?style=for-the-badge&logo=vite)

---

## ✨ Features

- 🌍 **45+ Languages** — culturally fluent, not just translated
- 🔢 **Real Math Engine** — JS executor, never guesses arithmetic
- 🧠 **Session Memory** — remembers name, facts, corrections
- 💔 **Crisis Detection** — immediate support mode with hotlines
- 🔒 **Privacy Protection** — warns before sensitive data is processed
- 🎯 **Goal Pinning** — stay focused mid-conversation
- ⚖️ **Political Balance** — multiple perspectives, never opinion as fact
- 🎤 **Voice Input** — speech recognition in 45+ languages
- 📷 **Image Analysis** — drag & drop or upload images
- ⚠️ **Anti-Hallucination** — uncertainty always surfaced

---

## 🚀 Quick Start (Local / VS Code)

### 1. Clone the repo

```bash
git clone https://github.com/<your-username>/jpd-ai.git
cd jpd-ai
```

### 2. Install dependencies

```bash
npm install
```

### 3. Add your API key

```bash
cp .env.example .env
```

Open `.env` and paste your Anthropic API key:

```
VITE_ANTHROPIC_API_KEY=sk-ant-your-key-here
```

Get a key at [console.anthropic.com](https://console.anthropic.com).

### 4. Run locally

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) — done!

---

## 📦 Publish to GitHub Pages

### Step 1 — Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/jpd-ai.git
git push -u origin main
```

### Step 2 — Add your API key as a GitHub Secret

1. Go to your repo → **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret**
3. Name: `VITE_ANTHROPIC_API_KEY`
4. Value: your `sk-ant-...` key
5. Click **Add secret**

### Step 3 — Enable GitHub Pages

1. Go to **Settings** → **Pages**
2. Under **Source**, select **GitHub Actions**
3. Save

### Step 4 — Set the base path (if deploying to a sub-path)

If your repo is named `jpd-ai` (not a username/org root site), open `vite.config.js` and uncomment:

```js
base: '/jpd-ai/',
```

Then commit and push. GitHub Actions will automatically build and deploy.

Your app will be live at:
```
https://<your-username>.github.io/jpd-ai/
```

---

## 🛠 Project Structure

```
jpd-ai/
├── .github/
│   └── workflows/
│       └── deploy.yml        # Auto-deploy to GitHub Pages on push
├── .vscode/
│   ├── extensions.json       # Recommended VS Code extensions
│   └── settings.json         # Editor settings (format on save, etc.)
├── public/
│   └── favicon.svg
├── src/
│   ├── App.jsx               # Main application (all-in-one component)
│   └── main.jsx              # React entry point
├── .env.example              # Template for API key
├── .gitignore
├── index.html
├── package.json
├── README.md
└── vite.config.js
```

---

## 🔐 Security Note

- **Never commit your `.env` file.** It's in `.gitignore`.
- For production, always use GitHub Secrets (or equivalent) to inject `VITE_ANTHROPIC_API_KEY` at build time.
- `VITE_` prefix exposes the key to the browser bundle — acceptable for personal/demo projects, but for a public-facing production app, proxy API calls through a backend.

---

## 🧑‍💻 VS Code Tips

Install the recommended extensions when prompted (`.vscode/extensions.json`):
- **Prettier** — auto-formats on save
- **ESLint** — catches issues as you type
- **ES7 React Snippets** — `rafce` → instant component scaffold
- **Error Lens** — inline error highlighting

Run the dev server directly from VS Code:
- Open terminal: `` Ctrl+` ``
- Run `npm run dev`
- Or use the built-in **Run and Debug** panel

---

## 📜 Scripts

| Command | Description |
|---|---|
| `npm run dev` | Start local dev server (hot reload) |
| `npm run build` | Build production bundle to `dist/` |
| `npm run preview` | Preview production build locally |

---

## License

MIT — use it, remix it, ship it.
