import { useState, useRef, useEffect, useCallback, useMemo } from "react";

/* ── FONTS ── */
const GFONTS = "https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,300&family=JetBrains+Mono:wght@400;500&display=swap";

/* ── LANGUAGES ── */
const LANGUAGES = [
  { code:"en",   name:"English",          native:"English",        flag:"🇬🇧", dir:"ltr", speech:"en-US",  region:"Global" },
  { code:"hi",   name:"Hindi",            native:"हिन्दी",           flag:"🇮🇳", dir:"ltr", speech:"hi-IN",  region:"South Asia" },
  { code:"bn",   name:"Bengali",          native:"বাংলা",           flag:"🇧🇩", dir:"ltr", speech:"bn-IN",  region:"South Asia" },
  { code:"ta",   name:"Tamil",            native:"தமிழ்",           flag:"🇮🇳", dir:"ltr", speech:"ta-IN",  region:"South Asia" },
  { code:"te",   name:"Telugu",           native:"తెలుగు",           flag:"🇮🇳", dir:"ltr", speech:"te-IN",  region:"South Asia" },
  { code:"kn",   name:"Kannada",          native:"ಕನ್ನಡ",            flag:"🇮🇳", dir:"ltr", speech:"kn-IN",  region:"South Asia" },
  { code:"ml",   name:"Malayalam",        native:"മലയാളം",          flag:"🇮🇳", dir:"ltr", speech:"ml-IN",  region:"South Asia" },
  { code:"mr",   name:"Marathi",          native:"मराठी",            flag:"🇮🇳", dir:"ltr", speech:"mr-IN",  region:"South Asia" },
  { code:"gu",   name:"Gujarati",         native:"ગુજરાતી",         flag:"🇮🇳", dir:"ltr", speech:"gu-IN",  region:"South Asia" },
  { code:"pa",   name:"Punjabi",          native:"ਪੰਜਾਬੀ",          flag:"🇮🇳", dir:"ltr", speech:"pa-IN",  region:"South Asia" },
  { code:"ur",   name:"Urdu",             native:"اردو",            flag:"🇵🇰", dir:"rtl", speech:"ur-PK",  region:"South Asia" },
  { code:"or",   name:"Odia",             native:"ଓଡ଼ିଆ",            flag:"🇮🇳", dir:"ltr", speech:"or-IN",  region:"South Asia" },
  { code:"ne",   name:"Nepali",           native:"नेपाली",           flag:"🇳🇵", dir:"ltr", speech:"ne-NP",  region:"South Asia" },
  { code:"si",   name:"Sinhala",          native:"සිංහල",           flag:"🇱🇰", dir:"ltr", speech:"si-LK",  region:"South Asia" },
  { code:"zh",   name:"Chinese",          native:"中文",             flag:"🇨🇳", dir:"ltr", speech:"zh-CN",  region:"East Asia" },
  { code:"ja",   name:"Japanese",         native:"日本語",            flag:"🇯🇵", dir:"ltr", speech:"ja-JP",  region:"East Asia" },
  { code:"ko",   name:"Korean",           native:"한국어",            flag:"🇰🇷", dir:"ltr", speech:"ko-KR",  region:"East Asia" },
  { code:"vi",   name:"Vietnamese",       native:"Tiếng Việt",     flag:"🇻🇳", dir:"ltr", speech:"vi-VN",  region:"SE Asia" },
  { code:"th",   name:"Thai",             native:"ภาษาไทย",         flag:"🇹🇭", dir:"ltr", speech:"th-TH",  region:"SE Asia" },
  { code:"id",   name:"Indonesian",       native:"Bahasa Indonesia",flag:"🇮🇩", dir:"ltr", speech:"id-ID",  region:"SE Asia" },
  { code:"ms",   name:"Malay",            native:"Bahasa Melayu",  flag:"🇲🇾", dir:"ltr", speech:"ms-MY",  region:"SE Asia" },
  { code:"tl",   name:"Filipino",         native:"Filipino",       flag:"🇵🇭", dir:"ltr", speech:"tl-PH",  region:"SE Asia" },
  { code:"ar",   name:"Arabic",           native:"العربية",         flag:"🇸🇦", dir:"rtl", speech:"ar-SA",  region:"Middle East" },
  { code:"fa",   name:"Persian",          native:"فارسی",           flag:"🇮🇷", dir:"rtl", speech:"fa-IR",  region:"Middle East" },
  { code:"tr",   name:"Turkish",          native:"Türkçe",         flag:"🇹🇷", dir:"ltr", speech:"tr-TR",  region:"Middle East" },
  { code:"he",   name:"Hebrew",           native:"עברית",           flag:"🇮🇱", dir:"rtl", speech:"he-IL",  region:"Middle East" },
  { code:"es",   name:"Spanish",          native:"Español",        flag:"🇪🇸", dir:"ltr", speech:"es-ES",  region:"Europe" },
  { code:"fr",   name:"French",           native:"Français",       flag:"🇫🇷", dir:"ltr", speech:"fr-FR",  region:"Europe" },
  { code:"de",   name:"German",           native:"Deutsch",        flag:"🇩🇪", dir:"ltr", speech:"de-DE",  region:"Europe" },
  { code:"pt",   name:"Portuguese",       native:"Português",      flag:"🇵🇹", dir:"ltr", speech:"pt-PT",  region:"Europe" },
  { code:"it",   name:"Italian",          native:"Italiano",       flag:"🇮🇹", dir:"ltr", speech:"it-IT",  region:"Europe" },
  { code:"ru",   name:"Russian",          native:"Русский",        flag:"🇷🇺", dir:"ltr", speech:"ru-RU",  region:"Europe" },
  { code:"pl",   name:"Polish",           native:"Polski",         flag:"🇵🇱", dir:"ltr", speech:"pl-PL",  region:"Europe" },
  { code:"nl",   name:"Dutch",            native:"Nederlands",     flag:"🇳🇱", dir:"ltr", speech:"nl-NL",  region:"Europe" },
  { code:"sv",   name:"Swedish",          native:"Svenska",        flag:"🇸🇪", dir:"ltr", speech:"sv-SE",  region:"Europe" },
  { code:"uk",   name:"Ukrainian",        native:"Українська",     flag:"🇺🇦", dir:"ltr", speech:"uk-UA",  region:"Europe" },
  { code:"el",   name:"Greek",            native:"Ελληνικά",       flag:"🇬🇷", dir:"ltr", speech:"el-GR",  region:"Europe" },
  { code:"sw",   name:"Swahili",          native:"Kiswahili",      flag:"🇰🇪", dir:"ltr", speech:"sw-KE",  region:"Africa" },
  { code:"am",   name:"Amharic",          native:"አማርኛ",           flag:"🇪🇹", dir:"ltr", speech:"am-ET",  region:"Africa" },
  { code:"yo",   name:"Yoruba",           native:"Yorùbá",         flag:"🇳🇬", dir:"ltr", speech:"yo-NG",  region:"Africa" },
  { code:"pt-BR",name:"Portuguese (BR)",  native:"Português BR",   flag:"🇧🇷", dir:"ltr", speech:"pt-BR",  region:"Americas" },
  { code:"es-MX",name:"Spanish (MX)",     native:"Español MX",     flag:"🇲🇽", dir:"ltr", speech:"es-MX",  region:"Americas" },
];

/* ── IN-MEMORY STORE (fixes localStorage which is blocked in artifacts) ── */
const MEM_STORE = { data: null };
const blankMem = () => ({ name:"", facts:[], topics:[], corrections:[], tone:"neutral", lang:"en", count:0, pinnedGoal:"" });
const loadMem  = () => MEM_STORE.data ? { ...blankMem(), ...MEM_STORE.data } : blankMem();
const saveMem  = (m) => { MEM_STORE.data = m; };

/* ── MATH ENGINE ── */
function mathEngine(text) {
  const pct = text.match(/(\d[\d,]*\.?\d*)\s*%\s*(?:of|de|von|का|এর|ல்)\s*[₹$£€¥]?\s*(\d[\d,]*\.?\d*)/i);
  if (pct) {
    const p = parseFloat(pct[1]), b = parseFloat(pct[2].replace(/,/g, "")), r = (p/100)*b;
    return { expr: `${p}% of ${b}`, result: r.toFixed(2) };
  }
  const ex = text.match(/(?:calculate|compute|what(?:'s| is)|=|solve)\s*([\d\s\+\-\*\/\^\(\)\.%√,]+)\s*[=?]?$/i)
          || text.match(/^([\d\s\+\-\*\/\^\(\)\.%,]+)[=?]$/);
  if (ex) {
    const e = ex[1].trim().replace(/√(\d+)/g, "Math.sqrt($1)").replace(/\^/g,"**").replace(/,/g,"");
    if (e.length > 1 && /\d/.test(e)) {
      try {
        // eslint-disable-next-line no-new-func
        const r = new Function(`"use strict"; return (${e})`)();
        if (typeof r === "number" && isFinite(r)) return { expr: ex[1].trim(), result: Number.isInteger(r) ? String(r) : parseFloat(r.toFixed(8)).toString() };
      } catch {}
    }
  }
  return null;
}

/* ── DETECTORS ── */
const detectCrisis  = t => /\b(suicide|kill myself|end my life|self.harm|want to die|no reason to live|helpless|crisis|cutting myself)\b/i.test(t);
const detectPrivacy = t => /(\b\d{16}\b|\bpassword\s*[:=]|\bssn\s*[:=]|\b\d{3}-\d{2}-\d{4}\b|api.?key\s*[:=])/i.test(t);
const detectTone    = t => /\b(hey|hi|lol|haha|btw|ngl|idk|bro|dude|omg)\b/i.test(t) ? "casual" : /\b(please|kindly|would you|formal|professional|sir)\b/i.test(t) ? "formal" : "neutral";
const detectRepeat  = (text, msgs) => {
  if (msgs.length < 4) return false;
  const prev = msgs.slice(-8).filter(m => m.role==="user").map(m => (Array.isArray(m.content) ? m.content.find(c=>c.type==="text")?.text : m.content) || "");
  const words = text.toLowerCase().split(/\s+/).filter(w => w.length > 4);
  return prev.some(p => words.filter(w => p.toLowerCase().includes(w)).length >= 3);
};
const extractFacts = (text, existing) => {
  const patterns = [
    { re: /(?:my name is|i(?:'m| am) called)\s+([A-Za-z\u0080-\uFFFF]{2,20})/i, label: "name" },
    { re: /i(?:'m| am)\s+(\d{1,3})\s+years?\s+old/i, label: "age" },
    { re: /(?:i(?:'m| am) from|i live in)\s+([\w\s,]{2,30}?)(?:\.|,|$)/i, label: "location" },
    { re: /(?:i(?:'m| am) a|i work as)\s+([\w\s]{2,30}?)(?:\.|,|$)/i, label: "profession" },
  ];
  const out = [...existing];
  patterns.forEach(({ re, label }) => {
    const m = text.match(re);
    if (m?.[1]) { const v = m[1].trim(); const i = out.findIndex(f => f.label===label); i >= 0 ? out[i] = {label,value:v} : out.push({label,value:v}); }
  });
  return out;
};

/* ── SYSTEM PROMPT ── */
function buildPrompt(langCode, mem, ctx) {
  const L = LANGUAGES.find(l => l.code === langCode) || LANGUAGES[0];
  const today = new Date().toLocaleDateString("en-US", { weekday:"long", year:"numeric", month:"long", day:"numeric" });
  const memStr = mem.facts.length ? `\nKNOWN FACTS: ${mem.facts.map(f=>`${f.label}=${f.value}`).join("; ")}` : "";
  const corrStr = mem.corrections?.length ? `\nCORRECTIONS TO APPLY: ${mem.corrections.slice(-4).map(c=>c.text).join("; ")}` : "";
  const goalStr = mem.pinnedGoal ? `\nPINNED GOAL: "${mem.pinnedGoal}" — always keep this in view` : "";
  const mathStr = ctx.math ? `\nMATH RESULT (use ONLY this): ${ctx.math.expr} = ${ctx.math.result}` : "";
  return `You are JPD.AI — the world's most honest, multilingual, and intelligent AI assistant.

LANGUAGE: Respond entirely in ${L.name} (${L.native}). Be culturally fluent — not just translated.
TODAY: ${today} (use for all temporal/age calculations)${memStr}${corrStr}${goalStr}${mathStr}

CORE RULES:
1. HONESTY: Never agree with wrong facts. If uncertain → say "I'm not certain, but…" before the claim. Never hallucinate.
2. MATH: If a math result is provided above, use ONLY that result. Never predict arithmetic. Show with 🔢.
3. ANTI-SYCOPHANCY: Correct wrong premises politely but firmly before answering.
4. BREVITY: Short questions → short answers. Never pad. Never over-explain.
5. COMPLETENESS: Address every point the user makes. Never silently skip items.
6. CONSISTENCY: Never contradict yourself within a session.
7. REFUSALS: When refusing, always say (a) what you can't do, (b) why, (c) what you CAN do instead.
8. TONE: Maintain ${mem.tone !== "neutral" ? mem.tone : "warm, professional"} tone consistently.
9. CAUSATION: Say "correlated, not necessarily causal" when appropriate.
10. PROACTIVE: After answering, if there's a highly useful follow-up, surface it with 💡.
${ctx.crisis ? "⚠ CRISIS: User may be in distress. Respond with warmth, no generic tips. Provide hotlines: India iCall 9152987821 | US 988 | UK Samaritans 116 123 | International befrienders.org" : ""}
${ctx.privacy ? "🔒 PRIVACY: Sensitive data detected. Warn the user NOT to share passwords/card numbers. Do not repeat the data." : ""}
${ctx.repeat ? "🔁 REPEAT: User asked this before. Don't rephrase — add new depth and insight." : ""}
${ctx.political ? "⚖ POLITICAL: Present ≥2 perspectives clearly labeled. Never state political opinion as fact." : ""}
${mem.pinnedGoal ? `🎯 GOAL: Always bring the conversation back to "${mem.pinnedGoal}" if it drifts.` : ""}

Be warm, curious, and genuinely helpful. You are a companion, not a search engine.`;
}

/* ── TEXT RENDERER (enhanced: supports headings, lists, horizontal rules) ── */
function Render({ text }) {
  const nodes = [];
  const lines = text.split("\n");
  let inCode = false, codeLines = [], codeLang = "";
  for (let i = 0; i < lines.length; i++) {
    const ln = lines[i];
    if (ln.startsWith("```")) {
      if (!inCode) { inCode = true; codeLang = ln.slice(3).trim(); codeLines = []; }
      else {
        nodes.push(
          <div key={i} style={{ margin:"12px 0", borderRadius:10, overflow:"hidden", border:"1px solid rgba(255,255,255,0.08)" }}>
            {codeLang && <div style={{ padding:"5px 14px", background:"rgba(255,255,255,0.04)", fontSize:11, color:"rgba(255,255,255,0.4)", fontFamily:"'JetBrains Mono',monospace", borderBottom:"1px solid rgba(255,255,255,0.07)", letterSpacing:".5px" }}>{codeLang}</div>}
            <pre style={{ background:"rgba(0,0,0,0.45)", padding:"14px 16px", margin:0, overflowX:"auto", fontSize:12.5, lineHeight:1.7, color:"#e2e8f0", fontFamily:"'JetBrains Mono',monospace" }}><code>{codeLines.join("\n")}</code></pre>
          </div>
        );
        inCode = false;
      }
    } else if (inCode) { codeLines.push(ln); }
    else if (ln.trim() === "---" || ln.trim() === "***") {
      nodes.push(<hr key={i} style={{ border:"none", borderTop:"1px solid rgba(255,255,255,0.07)", margin:"12px 0" }} />);
    } else if (/^#{1,3}\s/.test(ln)) {
      const level = ln.match(/^(#{1,3})/)[1].length;
      const headText = ln.replace(/^#{1,3}\s/, "");
      const sz = level === 1 ? 18 : level === 2 ? 15.5 : 13.5;
      nodes.push(<div key={i} style={{ fontSize:sz, fontWeight:700, color:"#f1f5f9", margin:"14px 0 6px", fontFamily:"'Syne',sans-serif", letterSpacing:"-.3px" }}>{headText}</div>);
    } else if (/^[-*]\s/.test(ln)) {
      nodes.push(
        <div key={i} style={{ display:"flex", gap:8, margin:"3px 0", fontSize:13.5, lineHeight:1.7, color:"#cbd5e1", paddingLeft:4 }}>
          <span style={{ color:"rgba(99,102,241,0.7)", marginTop:2, flexShrink:0 }}>▸</span>
          <span>{renderInline(ln.replace(/^[-*]\s/, ""))}</span>
        </div>
      );
    } else if (/^\d+\.\s/.test(ln)) {
      const num = ln.match(/^(\d+)\./)[1];
      nodes.push(
        <div key={i} style={{ display:"flex", gap:9, margin:"3px 0", fontSize:13.5, lineHeight:1.7, color:"#cbd5e1", paddingLeft:4 }}>
          <span style={{ color:"rgba(99,102,241,0.8)", fontWeight:700, fontFamily:"'JetBrains Mono',monospace", fontSize:11, minWidth:18, marginTop:3, flexShrink:0 }}>{num}.</span>
          <span>{renderInline(ln.replace(/^\d+\.\s/, ""))}</span>
        </div>
      );
    } else if (ln.trim()) {
      const isUncertain = /\b(not certain|uncertain|i think|probably|not sure|might be|i believe)\b/i.test(ln);
      const isTip = ln.startsWith("💡");
      const isCrisis = /hotline|crisis|iCall|Samaritans|befrienders|988/.test(ln);
      nodes.push(
        <p key={i} style={{
          margin:"0 0 8px 0", lineHeight:1.8, fontSize:13.5,
          ...(isUncertain ? { color:"#fbbf24", paddingLeft:12, borderLeft:"2px solid rgba(251,191,36,0.5)", background:"rgba(251,191,36,0.04)", borderRadius:"0 6px 6px 0", paddingTop:4, paddingBottom:4 } : {}),
          ...(isTip ? { color:"rgba(99,202,183,1)", background:"rgba(99,202,183,0.07)", padding:"6px 12px", borderRadius:8, borderLeft:"2px solid rgba(99,202,183,0.45)" } : {}),
          ...(isCrisis ? { color:"#fca5a5", background:"rgba(239,68,68,0.07)", padding:"6px 12px", borderRadius:8, borderLeft:"2px solid rgba(239,68,68,0.4)" } : {}),
        }}>
          {isUncertain && <span style={{ fontSize:9, fontWeight:700, letterSpacing:1, textTransform:"uppercase", background:"rgba(251,191,36,0.14)", border:"1px solid rgba(251,191,36,0.28)", borderRadius:3, padding:"1px 5px", marginRight:7, verticalAlign:"middle" }}>uncertain</span>}
          {renderInline(ln)}
        </p>
      );
    } else {
      nodes.push(<div key={i} style={{ height:6 }} />);
    }
  }
  return <div style={{ fontSize:13.5, lineHeight:1.8 }}>{nodes}</div>;
}

function renderInline(text) {
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);
  return parts.map((p, j) => {
    if (p.startsWith("`") && p.endsWith("`")) return <code key={j} style={{ background:"rgba(255,255,255,0.09)", border:"1px solid rgba(255,255,255,0.12)", padding:"1px 6px", borderRadius:4, fontSize:"0.875em", fontFamily:"'JetBrains Mono',monospace", color:"#f9a8d4" }}>{p.slice(1,-1)}</code>;
    if (p.startsWith("**") && p.endsWith("**")) return <strong key={j} style={{ fontWeight:600, color:"#f8fafc" }}>{p.slice(2,-2)}</strong>;
    if (p.startsWith("*") && p.endsWith("*")) return <em key={j} style={{ color:"rgba(255,255,255,0.7)", fontStyle:"italic" }}>{p.slice(1,-1)}</em>;
    return p;
  });
}

/* ── SUGGESTION CHIPS ── */
const CHIPS = [
  "What's 23% of ₹15,800?",
  "If I was born in 1997, how old am I?",
  "Explain quantum computing simply",
  "Write a Python function to sort a list",
  "What's the difference between AI and ML?",
  "Plan a 5-step marketing strategy",
  "Why is correlation not causation?",
  "My name is Alex — remember me!",
];

const FEATURES = [
  { ico:"⚠️", t:"Never fakes confidence",   d:"Uncertainty always shown. No hallucinated facts." },
  { ico:"🧠", t:"Remembers you",             d:"Name, facts, corrections saved across the session." },
  { ico:"🔢", t:"Real math engine",          d:"JS executor — never guesses arithmetic." },
  { ico:"🌍", t:`${LANGUAGES.length} languages`, d:"Culturally fluent, not just translated." },
  { ico:"💔", t:"Crisis detection",          d:"Immediate support mode when distress is sensed." },
  { ico:"🔒", t:"Privacy protection",        d:"Warns before sensitive data is processed." },
  { ico:"🎯", t:"Goal pinning",              d:"Pin a task — stay focused mid-conversation." },
  { ico:"⚖️", t:"Political balance",         d:"Multiple labeled perspectives, never opinion as fact." },
];

/* ── CSS ── */
const CSS = `
@import url('${GFONTS}');
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body, #root { height: 100%; }
body {
  font-family: 'DM Sans', sans-serif;
  background: #060610;
  color: #c4cfe0;
  overflow: hidden;
  -webkit-font-smoothing: antialiased;
}

/* ── SCROLLBAR ── */
::-webkit-scrollbar { width: 3px; height: 3px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 4px; }
::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.15); }

/* ── AMBIENT BACKGROUND ── */
.bg-canvas { position: fixed; inset: 0; pointer-events: none; z-index: 0; overflow: hidden; }
.bg-orb { position: absolute; border-radius: 50%; filter: blur(100px); }
.bg-orb-1 { width: 900px; height: 900px; background: radial-gradient(circle, rgba(67,56,202,0.18) 0%, transparent 65%); top: -400px; left: -250px; animation: orbDrift1 20s ease-in-out infinite; }
.bg-orb-2 { width: 700px; height: 700px; background: radial-gradient(circle, rgba(8,145,178,0.12) 0%, transparent 65%); bottom: -300px; right: -150px; animation: orbDrift2 25s ease-in-out infinite; }
.bg-orb-3 { width: 500px; height: 500px; background: radial-gradient(circle, rgba(124,58,237,0.09) 0%, transparent 65%); top: 40%; left: 35%; animation: orbDrift3 18s ease-in-out infinite; }
@keyframes orbDrift1 { 0%,100%{transform:translate(0,0);} 50%{transform:translate(40px,-30px);} }
@keyframes orbDrift2 { 0%,100%{transform:translate(0,0);} 50%{transform:translate(-30px,40px);} }
@keyframes orbDrift3 { 0%,100%{transform:translate(0,0) scale(1);} 50%{transform:translate(20px,20px) scale(1.1);} }
.bg-grid {
  position: absolute; inset: 0; opacity: 0.025;
  background-image: linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px);
  background-size: 48px 48px;
}

/* ── ROOT LAYOUT ── */
.root { display: flex; height: 100vh; overflow: hidden; position: relative; }

/* ── SIDEBAR ── */
.sidebar {
  width: 272px; flex-shrink: 0;
  background: rgba(255,255,255,0.018);
  border-right: 1px solid rgba(255,255,255,0.055);
  display: flex; flex-direction: column;
  position: relative; z-index: 10;
  backdrop-filter: blur(32px); -webkit-backdrop-filter: blur(32px);
  transition: transform .28s cubic-bezier(.16,1,.3,1);
}

/* BRAND */
.sb-brand { padding: 22px 18px 15px; border-bottom: 1px solid rgba(255,255,255,0.045); }
.brand-row { display: flex; align-items: center; gap: 12px; }
.brand-gem {
  width: 38px; height: 38px; border-radius: 11px; flex-shrink: 0;
  background: linear-gradient(135deg, #5b50f0 0%, #0ea5e9 100%);
  display: flex; align-items: center; justify-content: center;
  font-weight: 800; font-size: 16px; color: #fff; font-family: 'Syne', sans-serif;
  box-shadow: 0 0 24px rgba(91,80,240,0.4), 0 0 8px rgba(91,80,240,0.2);
  position: relative;
}
.brand-gem::after { content:''; position:absolute; inset:-1px; border-radius:12px; background:linear-gradient(135deg,rgba(255,255,255,0.15),rgba(255,255,255,0)); pointer-events:none; }
.brand-title { font-size: 17px; font-weight: 800; color: #f0f4fa; letter-spacing: -.5px; font-family: 'Syne', sans-serif; }
.brand-sub { font-size: 9.5px; color: rgba(255,255,255,0.22); letter-spacing: 1.8px; text-transform: uppercase; margin-top: 2px; }
.online-row { display: flex; align-items: center; gap: 7px; margin-top: 11px; flex-wrap: wrap; }
.online-dot { width: 6px; height: 6px; border-radius: 50%; background: #22c55e; animation: blink 2.5s ease-in-out infinite; flex-shrink: 0; }
@keyframes blink { 0%,100%{opacity:1;} 50%{opacity:0.35;} }
.online-label { font-size: 10.5px; color: rgba(255,255,255,0.25); }
.online-badges { display: flex; gap: 4px; margin-left: auto; }
.obadge { font-size: 8.5px; font-weight: 700; border-radius: 4px; padding: 2px 6px; letter-spacing: .5px; }
.ob-math { background: rgba(52,211,153,0.1); color: #34d399; border: 1px solid rgba(52,211,153,0.18); }
.ob-mem  { background: rgba(99,102,241,0.1); color: #818cf8; border: 1px solid rgba(99,102,241,0.18); }

/* TABS */
.sb-tabs { display: flex; gap: 2px; padding: 10px 12px 6px; }
.sbtab {
  flex: 1; padding: 7px 4px; border-radius: 7px; border: none;
  background: transparent; font-size: 10.5px; font-weight: 600;
  color: rgba(255,255,255,0.28); cursor: pointer;
  transition: all .18s; font-family: 'DM Sans', sans-serif; letter-spacing: .3px;
}
.sbtab.active { background: rgba(91,80,240,0.14); color: #a5b4fc; }
.sbtab:hover:not(.active) { color: rgba(255,255,255,0.5); background: rgba(255,255,255,0.04); }

/* SIDEBAR PANEL */
.sb-panel { flex: 1; overflow-y: auto; padding: 10px 13px 14px; }

/* Language panel */
.lang-search-inp {
  width: 100%; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.07);
  border-radius: 8px; padding: 8px 11px; font-size: 12.5px; color: #cbd5e1; outline: none;
  font-family: 'DM Sans', sans-serif; margin-bottom: 11px; transition: border-color .18s, background .18s;
}
.lang-search-inp:focus { border-color: rgba(91,80,240,0.4); background: rgba(91,80,240,0.05); }
.lang-search-inp::placeholder { color: rgba(255,255,255,0.18); }
.region-label {
  font-size: 9px; font-weight: 700; letter-spacing: 1.4px; text-transform: uppercase;
  color: rgba(255,255,255,0.18); padding: 9px 2px 5px; display: flex; align-items: center; gap: 7px;
}
.region-label::after { content:''; flex:1; height:1px; background:rgba(255,255,255,0.05); }
.lang-row {
  display: flex; align-items: center; gap: 9px; padding: 7px 9px; border-radius: 8px;
  cursor: pointer; transition: all .14s; margin-bottom: 1px; border: 1px solid transparent;
}
.lang-row:hover { background: rgba(255,255,255,0.045); }
.lang-row.sel { background: rgba(91,80,240,0.11); border-color: rgba(91,80,240,0.2); }
.lr-flag { font-size: 15px; width: 22px; text-align: center; flex-shrink: 0; }
.lr-name { font-size: 12.5px; font-weight: 500; color: #e2e8f0; }
.lr-eng  { font-size: 10px; color: rgba(255,255,255,0.28); }
.lr-check { width: 5px; height: 5px; border-radius: 50%; background: #6366f1; margin-left: auto; flex-shrink: 0; box-shadow: 0 0 6px rgba(99,102,241,0.6); }
.no-results { font-size: 12px; color: rgba(255,255,255,0.2); text-align: center; padding: 20px 0; }

/* Memory panel */
.mem-sec { font-size: 9px; font-weight: 700; letter-spacing: 1.4px; text-transform: uppercase; color: rgba(255,255,255,0.2); padding: 11px 0 5px; display: flex; align-items: center; gap: 7px; }
.mem-sec::after { content:''; flex:1; height:1px; background:rgba(255,255,255,0.05); }
.fact-row { display: flex; gap: 9px; background: rgba(255,255,255,0.035); border: 1px solid rgba(255,255,255,0.065); border-radius: 7px; padding: 7px 10px; margin-bottom: 5px; font-size: 12px; }
.fact-lbl { color: #818cf8; font-size: 9.5px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; flex-shrink: 0; padding-top: 1px; }
.fact-val { color: rgba(255,255,255,0.5); }
.topic-pill { display: inline-block; background: rgba(6,182,212,0.07); border: 1px solid rgba(6,182,212,0.14); border-radius: 20px; padding: 2px 9px; font-size: 10.5px; color: rgba(6,182,212,0.7); margin: 2px; }
.mem-empty { font-size: 12px; color: rgba(255,255,255,0.18); text-align: center; padding: 20px 0; line-height: 1.9; }
.mem-stat { font-size: 10.5px; color: rgba(255,255,255,0.18); margin-top: 10px; }
.clear-mem-btn {
  width: 100%; margin-top: 10px; padding: 8px; border-radius: 8px;
  border: 1px solid rgba(239,68,68,0.16); background: rgba(239,68,68,0.05);
  color: rgba(239,68,68,0.55); font-size: 11.5px; cursor: pointer;
  font-family: 'DM Sans', sans-serif; transition: all .18s;
}
.clear-mem-btn:hover { background: rgba(239,68,68,0.1); color: #f87171; border-color: rgba(239,68,68,0.25); }

/* Sidebar footer */
.sb-footer { padding: 10px 14px; border-top: 1px solid rgba(255,255,255,0.045); display: flex; gap: 10px; flex-wrap: wrap; }
.sf-item { display: flex; align-items: center; gap: 5px; }
.sf-dot { width: 5px; height: 5px; border-radius: 50%; flex-shrink: 0; }
.sf-lbl { font-size: 9.5px; color: rgba(255,255,255,0.22); }

/* ── MAIN AREA ── */
.main { flex: 1; display: flex; flex-direction: column; overflow: hidden; position: relative; z-index: 5; }

/* Header */
.chat-header {
  padding: 13px 22px; display: flex; align-items: center; justify-content: space-between;
  border-bottom: 1px solid rgba(255,255,255,0.05);
  background: rgba(6,6,16,0.75); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px);
  flex-shrink: 0;
}
.ch-left { display: flex; align-items: center; gap: 10px; }
.mob-menu-btn {
  display: none; width: 30px; height: 30px; border-radius: 7px;
  border: 1px solid rgba(255,255,255,0.08); background: transparent;
  color: rgba(255,255,255,0.4); cursor: pointer; align-items: center; justify-content: center;
}
.model-pill {
  display: flex; align-items: center; gap: 7px;
  background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.07);
  border-radius: 20px; padding: 5px 13px 5px 10px; font-size: 12px; color: rgba(255,255,255,0.5);
  font-family: 'DM Sans', sans-serif; font-weight: 500;
}
.mp-dot { width: 6px; height: 6px; border-radius: 50%; background: #22c55e; animation: blink 2.5s infinite; flex-shrink: 0; }
.ch-badges { display: flex; gap: 5px; flex-wrap: wrap; }
.hb { font-size: 9.5px; border-radius: 5px; padding: 3px 8px; font-weight: 700; letter-spacing: .3px; white-space: nowrap; }
.hb-indigo { background: rgba(99,102,241,0.1); color: #818cf8; border: 1px solid rgba(99,102,241,0.18); }
.hb-cyan   { background: rgba(6,182,212,0.09);  color: #22d3ee; border: 1px solid rgba(6,182,212,0.16); }
.hb-green  { background: rgba(34,197,94,0.09);   color: #4ade80; border: 1px solid rgba(34,197,94,0.16); }
.hb-amber  { background: rgba(251,191,36,0.09);   color: #fbbf24; border: 1px solid rgba(251,191,36,0.16); }

/* Pinned goal */
.pinned-bar {
  margin: 8px 22px 0; padding: 8px 14px; border-radius: 9px;
  background: rgba(234,179,8,0.07); border: 1px solid rgba(234,179,8,0.16);
  display: flex; align-items: center; gap: 9px; font-size: 12px; color: #fbbf24;
  flex-shrink: 0;
}
.pb-label { font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: rgba(251,191,36,0.55); flex-shrink: 0; }
.pb-clear { background: transparent; border: none; cursor: pointer; color: rgba(251,191,36,0.35); font-size: 18px; line-height: 1; margin-left: auto; padding: 0; transition: color .15s; }
.pb-clear:hover { color: rgba(251,191,36,0.7); }

/* Messages area */
.msgs-wrap { flex: 1; overflow-y: auto; padding: 28px 22px 16px; }
.msgs-inner { max-width: 760px; margin: 0 auto; display: flex; flex-direction: column; gap: 20px; }

/* Welcome screen */
.welcome {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  min-height: 100%; padding: 40px 20px; text-align: center;
  animation: fadeSlide .65s cubic-bezier(.16,1,.3,1);
}
@keyframes fadeSlide { from{opacity:0;transform:translateY(22px);}to{opacity:1;transform:translateY(0);} }
.w-gem-wrap { position: relative; margin-bottom: 30px; }
.w-gem {
  width: 82px; height: 82px; border-radius: 23px;
  background: linear-gradient(145deg, #5b50f0 0%, #0ea5e9 100%);
  display: flex; align-items: center; justify-content: center;
  font-size: 33px; font-weight: 800; color: #fff; font-family: 'Syne', sans-serif;
  box-shadow: 0 0 0 1px rgba(91,80,240,0.3), 0 0 60px rgba(91,80,240,0.28), 0 0 120px rgba(14,165,233,0.12);
  animation: gemFloat 5s ease-in-out infinite;
}
@keyframes gemFloat { 0%,100%{transform:translateY(0) rotate(-1deg);} 50%{transform:translateY(-9px) rotate(1deg);} }
.w-ring {
  position: absolute; inset: -14px; border-radius: 37px;
  border: 1.5px solid rgba(91,80,240,0.2);
  animation: ringBreath 5s ease-in-out infinite;
}
.w-ring2 {
  position: absolute; inset: -26px; border-radius: 49px;
  border: 1px solid rgba(14,165,233,0.1);
  animation: ringBreath 5s ease-in-out infinite; animation-delay: .5s;
}
@keyframes ringBreath { 0%,100%{opacity:.3;transform:scale(1);} 50%{opacity:.7;transform:scale(1.03);} }
.w-title {
  font-size: 36px; font-weight: 800; letter-spacing: -1.5px; margin-bottom: 11px;
  font-family: 'Syne', sans-serif;
  background: linear-gradient(135deg, #f0f4fa 20%, rgba(165,180,252,0.8) 70%, rgba(34,211,238,0.7) 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}
.w-sub { font-size: 13.5px; color: rgba(255,255,255,0.3); max-width: 440px; line-height: 1.8; margin-bottom: 6px; font-weight: 300; }
.w-lang-line { font-size: 11.5px; color: rgba(99,102,241,0.65); margin-bottom: 30px; font-weight: 600; letter-spacing: .2px; }
.feat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; max-width: 620px; margin-bottom: 30px; }
.feat-card {
  background: rgba(255,255,255,0.025); border: 1px solid rgba(255,255,255,0.06);
  border-radius: 13px; padding: 14px 15px; text-align: left;
  transition: all .22s; cursor: default;
}
.feat-card:hover { background: rgba(91,80,240,0.07); border-color: rgba(91,80,240,0.18); transform: translateY(-1px); }
.fc-ico { font-size: 17px; margin-bottom: 8px; }
.fc-t { font-size: 12.5px; font-weight: 700; color: #eef2f8; margin-bottom: 4px; font-family: 'Syne', sans-serif; letter-spacing: -.2px; }
.fc-d { font-size: 11px; color: rgba(255,255,255,0.28); line-height: 1.55; }
.suggestions { display: flex; flex-wrap: wrap; gap: 7px; justify-content: center; max-width: 660px; }
.sug {
  background: rgba(255,255,255,0.035); border: 1px solid rgba(255,255,255,0.07);
  border-radius: 24px; padding: 8px 16px; font-size: 12px; color: rgba(255,255,255,0.5);
  cursor: pointer; transition: all .2s; font-family: 'DM Sans', sans-serif; font-weight: 500;
}
.sug:hover { background: rgba(91,80,240,0.11); border-color: rgba(91,80,240,0.28); color: #a5b4fc; transform: translateY(-2px); box-shadow: 0 4px 14px rgba(91,80,240,0.12); }

/* Message rows */
.mrow { display: flex; gap: 10px; animation: msgPop .3s cubic-bezier(.16,1,.3,1); }
.mrow.user { flex-direction: row-reverse; }
@keyframes msgPop { from{opacity:0;transform:translateY(10px);} to{opacity:1;transform:translateY(0);} }
.avatar {
  width: 30px; height: 30px; border-radius: 50%; flex-shrink: 0; margin-top: 3px;
  display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700;
  font-family: 'Syne', sans-serif;
}
.av-ai { background: linear-gradient(135deg, #5b50f0, #0ea5e9); color: #fff; box-shadow: 0 0 14px rgba(91,80,240,0.35); }
.av-user { background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.1); color: rgba(255,255,255,0.45); }
.bubble {
  max-width: calc(100% - 48px); padding: 13px 16px; border-radius: 16px;
  font-size: 13.5px; line-height: 1.8;
}
.bub-ai {
  background: rgba(255,255,255,0.033); border: 1px solid rgba(255,255,255,0.075);
  border-top-left-radius: 4px; color: #c4cfe0;
}
.bub-user {
  background: rgba(91,80,240,0.1); border: 1px solid rgba(91,80,240,0.18);
  border-top-right-radius: 4px; color: #dde4f2; font-weight: 400;
}
.bub-crisis { background: rgba(239,68,68,0.07) !important; border-color: rgba(239,68,68,0.18) !important; }
.msg-img { max-width: 220px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.08); display: block; margin-bottom: 9px; }
.math-chip {
  display: flex; align-items: center; gap: 11px; margin-bottom: 11px;
  background: rgba(34,197,94,0.06); border: 1px solid rgba(34,197,94,0.13); border-radius: 10px; padding: 10px 14px;
}
.math-expr { font-size: 11px; color: rgba(34,197,94,0.5); font-family: 'JetBrains Mono',monospace; }
.math-res  { font-size: 19px; font-weight: 700; color: #4ade80; font-family: 'Syne', sans-serif; }
.privacy-alert { background: rgba(239,68,68,0.07); border: 1px solid rgba(239,68,68,0.15); border-radius: 8px; padding: 7px 11px; margin-bottom: 9px; font-size: 12px; color: rgba(248,113,113,0.85); }
.repeat-tag { display: inline-block; font-size: 9.5px; background: rgba(251,191,36,0.09); border: 1px solid rgba(251,191,36,0.18); border-radius: 4px; padding: 2px 8px; color: #fbbf24; margin-bottom: 8px; font-weight: 700; letter-spacing: .3px; }
.msg-footer { display: flex; align-items: center; gap: 6px; padding: 4px 2px 0; }
.msg-time { font-size: 9.5px; color: rgba(255,255,255,0.16); }
.fb-btn { background: transparent; border: none; cursor: pointer; font-size: 12px; opacity: .3; transition: opacity .15s, transform .15s; padding: 0; }
.fb-btn:hover { opacity: .9; transform: scale(1.15); }
.fb-btn.active-like { opacity: 1; filter: drop-shadow(0 0 4px #4ade80); }
.fb-btn.active-dislike { opacity: 1; filter: drop-shadow(0 0 4px #f87171); }

/* Typing indicator */
.typing-row { display: flex; gap: 10px; }
.typing-bub {
  background: rgba(255,255,255,0.033); border: 1px solid rgba(255,255,255,0.07);
  border-radius: 16px; border-top-left-radius: 4px; padding: 15px 18px;
  display: flex; gap: 5px; align-items: center;
}
.td { width: 5px; height: 5px; border-radius: 50%; background: rgba(255,255,255,0.22); animation: tdBounce 1.3s ease-in-out infinite; }
.td:nth-child(2){animation-delay:.16s;} .td:nth-child(3){animation-delay:.32s;}
@keyframes tdBounce { 0%,60%,100%{transform:translateY(0);opacity:.25;} 30%{transform:translateY(-5px);opacity:.85;} }

/* ── INPUT AREA ── */
.input-area {
  padding: 12px 22px 17px; flex-shrink: 0;
  border-top: 1px solid rgba(255,255,255,0.045);
  background: rgba(6,6,16,0.85); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px);
}
.preview-strip { max-width: 760px; margin: 0 auto 9px; display: flex; gap: 7px; flex-wrap: wrap; }
.prev-wrap { position: relative; }
.prev-img { width: 52px; height: 52px; object-fit: cover; border-radius: 8px; border: 1px solid rgba(255,255,255,0.09); display: block; }
.prev-rm { position: absolute; top: -5px; right: -5px; width: 17px; height: 17px; border-radius: 50%; background: #ef4444; border: none; cursor: pointer; color: #fff; font-size: 10px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 6px rgba(0,0,0,0.4); }
.rec-bar-wrap { max-width: 760px; margin: 0 auto 9px; }
.rec-bar {
  display: flex; align-items: center; gap: 9px;
  background: rgba(239,68,68,0.07); border: 1px solid rgba(239,68,68,0.18);
  border-radius: 10px; padding: 9px 13px;
}
.rec-dot { width: 7px; height: 7px; border-radius: 50%; background: #ef4444; animation: blink 1s infinite; flex-shrink: 0; }
.rec-text { font-size: 12px; color: rgba(248,113,113,.85); flex: 1; }
.rec-timer { font-size: 11.5px; color: rgba(248,113,113,.65); font-family: 'JetBrains Mono',monospace; }
.rec-stop-btn { width: 24px; height: 24px; border-radius: 5px; background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.25); cursor: pointer; color: #f87171; display: flex; align-items: center; justify-content: center; transition: background .15s; }
.rec-stop-btn:hover { background: rgba(239,68,68,0.25); }
.goal-pin-bar { max-width: 760px; margin: 0 auto 9px; display: flex; gap: 7px; }
.goal-pin-inp {
  flex: 1; background: rgba(255,255,255,0.04); border: 1px solid rgba(251,191,36,0.18);
  border-radius: 9px; padding: 8px 12px; font-size: 12.5px; color: #e2e8f0; outline: none;
  font-family: 'DM Sans', sans-serif; transition: border-color .18s, background .18s;
}
.goal-pin-inp:focus { border-color: rgba(251,191,36,0.4); background: rgba(251,191,36,0.04); }
.goal-pin-inp::placeholder { color: rgba(255,255,255,0.18); }
.goal-go-btn { padding: 8px 14px; background: rgba(251,191,36,0.09); border: 1px solid rgba(251,191,36,0.2); border-radius: 9px; color: #fbbf24; font-size: 12px; cursor: pointer; white-space: nowrap; font-family: 'DM Sans', sans-serif; font-weight: 600; transition: all .18s; }
.goal-go-btn:hover { background: rgba(251,191,36,0.16); }
.goal-cancel-btn { padding: 8px 13px; background: transparent; border: 1px solid rgba(255,255,255,0.07); border-radius: 9px; color: rgba(255,255,255,0.28); font-size: 12px; cursor: pointer; font-family: 'DM Sans', sans-serif; transition: all .18s; }
.goal-cancel-btn:hover { color: rgba(255,255,255,0.5); border-color: rgba(255,255,255,0.12); }

/* Input wrapper */
.iw {
  max-width: 760px; margin: 0 auto; display: flex; align-items: flex-end; gap: 7px;
  background: rgba(255,255,255,0.035); border: 1px solid rgba(255,255,255,0.08);
  border-radius: 15px; padding: 9px 9px 9px 13px; transition: border-color .2s, box-shadow .2s;
}
.iw:focus-within { border-color: rgba(91,80,240,0.35); box-shadow: 0 0 0 3px rgba(91,80,240,0.06); }
.itxt {
  flex: 1; background: transparent; border: none; outline: none;
  font-family: 'DM Sans', sans-serif; font-size: 13.5px; color: #dde4f2;
  resize: none; max-height: 160px; min-height: 24px; line-height: 1.65; padding: 3px 0;
}
.itxt::placeholder { color: rgba(255,255,255,0.18); }
.action-btn {
  width: 32px; height: 32px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.07);
  background: rgba(255,255,255,0.03); cursor: pointer; display: flex; align-items: center;
  justify-content: center; flex-shrink: 0; transition: all .18s; color: rgba(255,255,255,0.3);
}
.action-btn svg { width: 14px; height: 14px; }
.action-btn:hover { background: rgba(255,255,255,0.07); border-color: rgba(255,255,255,0.12); color: rgba(255,255,255,0.65); }
.action-btn.recording { background: rgba(239,68,68,0.1); border-color: rgba(239,68,68,0.25); color: #f87171; position: relative; }
.action-btn.recording::after { content:''; position:absolute; inset:-4px; border-radius:12px; border:1.5px solid rgba(239,68,68,0.22); animation:ripple 1.3s ease-out infinite; }
@keyframes ripple { 0%{transform:scale(1);opacity:.6;} 100%{transform:scale(2.4);opacity:0;} }
.send-btn {
  width: 34px; height: 34px; border-radius: 10px; flex-shrink: 0;
  background: linear-gradient(145deg, #5b50f0, #0ea5e9);
  border: none; cursor: pointer; display: flex; align-items: center; justify-content: center;
  transition: all .18s; box-shadow: 0 0 18px rgba(91,80,240,0.3);
  position: relative; overflow: hidden;
}
.send-btn::after { content:''; position:absolute; inset:0; background:linear-gradient(135deg,rgba(255,255,255,0.15),rgba(255,255,255,0)); border-radius:10px; pointer-events:none; }
.send-btn:hover:not(:disabled) { transform: scale(1.07); box-shadow: 0 0 28px rgba(91,80,240,0.45); }
.send-btn:active:not(:disabled) { transform: scale(.96); }
.send-btn:disabled { opacity: .25; cursor: not-allowed; box-shadow: none; }
.send-btn svg { width: 13px; height: 13px; fill: none; stroke: #fff; stroke-width: 2.3; stroke-linecap: round; stroke-linejoin: round; position: relative; z-index: 1; }
.input-hints { max-width: 760px; margin: 8px auto 0; display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
.ih { display: flex; align-items: center; gap: 4px; font-size: 10px; color: rgba(255,255,255,0.18); }
.kbd-hint { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.09); border-radius: 3px; padding: 1px 5px; font-size: 9px; font-family: 'JetBrains Mono',monospace; color: rgba(255,255,255,0.25); }
.err-bar { max-width: 760px; margin: 0 auto 10px; background: rgba(239,68,68,0.07); border: 1px solid rgba(239,68,68,0.18); border-radius: 9px; padding: 9px 13px; font-size: 12.5px; color: rgba(248,113,113,.85); }

/* Copy button */
.copy-btn { background: transparent; border: none; cursor: pointer; font-size: 11px; opacity: .3; transition: opacity .15s; padding: 0; color: rgba(255,255,255,0.5); margin-left: auto; }
.copy-btn:hover { opacity: .8; }
.copy-btn.copied { opacity: 1; color: #4ade80; }

/* Mobile */
@media(max-width:680px){
  .sidebar { position:fixed; left:0; top:0; bottom:0; z-index:100; transform:translateX(-100%); transition:transform .28s cubic-bezier(.16,1,.3,1); }
  .sidebar.open { transform:translateX(0); }
  .mob-menu-btn { display:flex; }
  .ch-badges { display:none; }
  .feat-grid { grid-template-columns:1fr; }
  .w-title { font-size:28px; }
  .msgs-wrap { padding: 20px 14px 12px; }
  .input-area { padding: 10px 14px 14px; }
}
/* Overlay for mobile sidebar */
.sb-overlay { display:none; }
@media(max-width:680px){
  .sb-overlay.visible { display:block; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:99; backdrop-filter:blur(4px); }
}
`;

/* ══════════════════════════════════════════
   MAIN APP
══════════════════════════════════════════ */
export default function App() {
  // Single loadMem() call to init both mem and lang
  const [mem, setMem] = useState(() => {
    const m = loadMem();
    return m;
  });
  const [lang, setLang]       = useState(() => loadMem().lang || "en");
  const [messages, setMsgs]   = useState([]);
  const [input, setInput]     = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");
  const [images, setImages]   = useState([]);
  const [recording, setRec]   = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const [sideOpen, setSide]   = useState(false);
  const [panel, setPanel]     = useState("lang");
  const [langQ, setLangQ]     = useState("");
  const [showGoal, setShowGoal] = useState(false);
  const [goalInput, setGoalInput] = useState("");
  const [feedback, setFeedback]  = useState({});
  const [copiedIdx, setCopied]   = useState(null);

  const bottomRef = useRef(null);
  const taRef     = useRef(null);
  const fileRef   = useRef(null);
  const recRef    = useRef(null);
  const timerRef  = useRef(null);

  const curLang = useMemo(() => LANGUAGES.find(l => l.code === lang) || LANGUAGES[0], [lang]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:"smooth" }); }, [messages, loading]);

  const updMem = useCallback((upd) => {
    setMem(p => { const n = { ...p, ...upd }; saveMem(n); return n; });
  }, []);

  const switchLang = (code) => { setLang(code); updMem({ lang: code }); setSide(false); };

  const resize = () => {
    const t = taRef.current; if (!t) return;
    t.style.height = "auto";
    t.style.height = Math.min(t.scrollHeight, 160) + "px";
  };

  const fmt = (s) => `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;

  const filtLangs = useMemo(() => {
    const q = langQ.toLowerCase().trim();
    if (!q) return LANGUAGES;
    return LANGUAGES.filter(l => l.name.toLowerCase().includes(q) || l.native.toLowerCase().includes(q) || l.region.toLowerCase().includes(q));
  }, [langQ]);

  const langGroups = useMemo(() => {
    const g = {};
    filtLangs.forEach(l => { if (!g[l.region]) g[l.region] = []; g[l.region].push(l); });
    return g;
  }, [filtLangs]);

  /* ── Files ── */
  const handleFiles = (e) => {
    Array.from(e.target.files || []).forEach(f => {
      if (!f.type.startsWith("image/")) return;
      const r = new FileReader();
      r.onload = ev => setImages(p => [...p, { url: ev.target.result, b64: ev.target.result.split(",")[1], type: f.type }]);
      r.readAsDataURL(f);
    });
    e.target.value = "";
  };

  /* ── Voice ── */
  const startRec = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setError("Voice input requires Chrome or Edge."); return; }
    const rec = new SR();
    rec.continuous = true; rec.interimResults = true;
    rec.lang = curLang.speech || "en-US";
    recRef.current = rec;
    setRecSecs(0);
    timerRef.current = setInterval(() => setRecSecs(s => s + 1), 1000);
    rec.onstart  = () => setRec(true);
    rec.onresult = (e) => { let t = ""; for (let i = e.resultIndex; i < e.results.length; i++) t += e.results[i][0].transcript; setInput(p => p + t); setTimeout(resize, 0); };
    rec.onend    = () => { setRec(false); clearInterval(timerRef.current); setRecSecs(0); };
    rec.onerror  = (e) => { setRec(false); clearInterval(timerRef.current); setError("Voice error: " + e.error); };
    rec.start();
  };
  const stopRec = () => { recRef.current?.stop(); setRec(false); clearInterval(timerRef.current); setRecSecs(0); };

  /* ── Goal ── */
  const pinGoal  = () => { if (!goalInput.trim()) return; updMem({ pinnedGoal: goalInput.trim() }); setGoalInput(""); setShowGoal(false); };
  const clearGoal = () => updMem({ pinnedGoal: "" });

  /* ── Copy message ── */
  const copyMsg = (text, idx) => {
    navigator.clipboard?.writeText(text).then(() => { setCopied(idx); setTimeout(() => setCopied(null), 1600); });
  };

  /* ── SEND ── */
  const send = async (override) => {
    const text = (override !== undefined ? override : input).trim();
    if ((!text && images.length === 0) || loading) return;
    setInput(""); setError("");
    if (taRef.current) taRef.current.style.height = "auto";

    const math      = text ? mathEngine(text) : null;
    const crisis    = text ? detectCrisis(text) : false;
    const privacy   = text ? detectPrivacy(text) : false;
    const repeat    = detectRepeat(text, messages);
    const political = text ? /\b(politics|election|president|democrat|republican|liberal|conservative)\b/i.test(text) : false;
    const tone      = detectTone(text);
    const newFacts  = extractFacts(text, mem.facts);
    const topic     = text ? text.split(/\s+/).slice(0,5).join(" ").substring(0,50) : null;
    const newTopics = topic ? [...(mem.topics||[]).slice(-19), topic] : mem.topics;
    const newTone   = (mem.tone === "neutral" && tone !== "neutral") ? tone : mem.tone;

    updMem({ facts: newFacts, topics: newTopics, tone: newTone, count: (mem.count||0) + 1 });

    const imgSnaps = [...images];
    const content  = [];
    imgSnaps.forEach(img => content.push({ type:"image", source:{ type:"base64", media_type: img.type, data: img.b64 } }));
    if (text) content.push({ type:"text", text });
    setImages([]);

    const ts = new Date().toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" });
    const userDisp = { text, imgs: imgSnaps.map(i => i.url), math, crisis, privacy, repeat, ts };
    const newMsgs = [...messages, { role:"user", content, disp: userDisp }];
    setMsgs(newMsgs);
    setLoading(true);

    const sys = buildPrompt(lang, { ...mem, facts: newFacts, tone: newTone }, { math, crisis, privacy, repeat, political, pinnedGoal: mem.pinnedGoal || "" });
    const apiMsgs = newMsgs.map(m => ({ role: m.role, content: m.content }));

    try {
      const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY;
      if (!apiKey) throw new Error("API key not set. Add VITE_ANTHROPIC_API_KEY to your .env file.");
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1400, system: sys, messages: apiMsgs }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      const reply = data.content?.[0]?.text || "Sorry, I couldn't respond.";
      const aiTs = new Date().toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" });
      setMsgs([...newMsgs, { role:"assistant", content:[{type:"text",text:reply}], disp:{ text:reply, imgs:[], ts:aiTs } }]);
    } catch (e) {
      setError("⚠ " + e.message);
    } finally {
      setLoading(false);
    }
  };

  const onKey    = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } };
  const canSend  = (input.trim() || images.length > 0) && !loading;
  const giveFeedback = (idx, type) => {
    setFeedback(p => ({ ...p, [idx]: type }));
    if (type === "dislike") {
      const msg = messages[idx];
      const txt = msg?.disp?.text?.substring(0, 50) || "response";
      updMem({ corrections: [...(mem.corrections||[]), { text: `Marked unhelpful: "${txt}"` }] });
    }
  };

  return (
    <>
      <style>{CSS}</style>
      <div className="bg-canvas">
        <div className="bg-orb bg-orb-1" />
        <div className="bg-orb bg-orb-2" />
        <div className="bg-orb bg-orb-3" />
        <div className="bg-grid" />
      </div>

      {/* Mobile overlay */}
      <div className={`sb-overlay ${sideOpen ? "visible" : ""}`} onClick={() => setSide(false)} />

      <div className="root">
        {/* ═══════════ SIDEBAR ═══════════ */}
        <aside className={`sidebar ${sideOpen ? "open" : ""}`}>
          <div className="sb-brand">
            <div className="brand-row">
              <div className="brand-gem">J</div>
              <div>
                <div className="brand-title">JPD.AI</div>
                <div className="brand-sub">50 AI Flaws Fixed</div>
              </div>
            </div>
            <div className="online-row">
              <div className="online-dot" />
              <span className="online-label">{LANGUAGES.length} languages active</span>
              <div className="online-badges">
                <span className="obadge ob-math">🔢 Math</span>
                <span className="obadge ob-mem">🧠 Mem</span>
              </div>
            </div>
          </div>

          <div className="sb-tabs">
            {["lang","memory","settings"].map(t => (
              <button key={t} className={`sbtab ${panel===t?"active":""}`} onClick={() => setPanel(t)}>
                {t === "lang" ? "🌍 Lang" : t === "memory" ? "🧠 Memory" : "⚙ Settings"}
              </button>
            ))}
          </div>

          <div className="sb-panel">
            {/* Language Panel */}
            {panel === "lang" && (
              <>
                <input className="lang-search-inp" placeholder={`Search ${LANGUAGES.length} languages…`} value={langQ} onChange={e => setLangQ(e.target.value)} />
                {filtLangs.length === 0
                  ? <div className="no-results">No language found for "{langQ}"</div>
                  : Object.entries(langGroups).map(([region, langs]) => (
                      <div key={region}>
                        <div className="region-label">{region}</div>
                        {langs.map(l => (
                          <div key={l.code} className={`lang-row ${l.code === lang ? "sel" : ""}`} onClick={() => switchLang(l.code)}>
                            <span className="lr-flag">{l.flag}</span>
                            <div style={{ flex:1, minWidth:0 }}>
                              <div className="lr-name">{l.native}</div>
                              <div className="lr-eng">{l.name}{l.dir==="rtl" ? " · RTL" : ""}</div>
                            </div>
                            {l.code === lang && <div className="lr-check" />}
                          </div>
                        ))}
                      </div>
                    ))
                }
              </>
            )}

            {/* Memory Panel */}
            {panel === "memory" && (
              <>
                {mem.facts.length === 0 && mem.topics.length === 0
                  ? <div className="mem-empty">No memory yet.<br />Tell me your name, job, or location<br />and I'll remember you 🧠</div>
                  : <>
                      {mem.facts.length > 0 && (
                        <>
                          <div className="mem-sec">About you</div>
                          {mem.facts.map((f,i) => (
                            <div key={i} className="fact-row">
                              <span className="fact-lbl">{f.label}</span>
                              <span className="fact-val">{f.value}</span>
                            </div>
                          ))}
                        </>
                      )}
                      {mem.topics.length > 0 && (
                        <>
                          <div className="mem-sec">Recent topics</div>
                          <div>{mem.topics.slice(-10).map((t,i) => <span key={i} className="topic-pill">{t}</span>)}</div>
                        </>
                      )}
                      {mem.corrections?.length > 0 && (
                        <>
                          <div className="mem-sec">Corrections stored</div>
                          {mem.corrections.slice(-3).map((c,i) => (
                            <div key={i} style={{ fontSize:11, color:"rgba(255,255,255,0.28)", padding:"4px 0" }}>• {c.text}</div>
                          ))}
                        </>
                      )}
                      <div className="mem-stat">{mem.count||0} messages · Tone: {mem.tone}</div>
                    </>
                }
                <button className="clear-mem-btn" onClick={() => { const f=blankMem(); f.lang=lang; setMem(f); saveMem(f); }}>
                  🗑 Clear all memory
                </button>
              </>
            )}

            {/* Settings Panel */}
            {panel === "settings" && (
              <>
                <div className="mem-sec">Active Language</div>
                <div style={{ background:"rgba(91,80,240,0.07)", border:"1px solid rgba(91,80,240,0.16)", borderRadius:10, padding:"10px 13px", display:"flex", alignItems:"center", gap:11, marginBottom:14 }}>
                  <span style={{ fontSize:22 }}>{curLang.flag}</span>
                  <div>
                    <div style={{ fontSize:13.5, fontWeight:700, color:"#f1f5f9", fontFamily:"'Syne',sans-serif" }}>{curLang.native}</div>
                    <div style={{ fontSize:10.5, color:"rgba(255,255,255,0.28)" }}>{curLang.name} · {curLang.region}{curLang.dir==="rtl"?" · RTL":""}</div>
                  </div>
                </div>
                <div className="mem-sec">Pinned Goal</div>
                {mem.pinnedGoal
                  ? <div style={{ background:"rgba(251,191,36,0.07)", border:"1px solid rgba(251,191,36,0.18)", borderRadius:9, padding:"9px 12px", fontSize:12, color:"#fbbf24", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                      <span>{mem.pinnedGoal}</span>
                      <button onClick={clearGoal} style={{ background:"transparent", border:"none", cursor:"pointer", color:"rgba(251,191,36,0.4)", fontSize:18, lineHeight:1 }}>×</button>
                    </div>
                  : <button style={{ width:"100%", padding:"9px", background:"rgba(251,191,36,0.06)", border:"1px solid rgba(251,191,36,0.16)", borderRadius:9, color:"#fbbf24", fontSize:12, cursor:"pointer", fontFamily:"'DM Sans',sans-serif", fontWeight:600 }} onClick={() => { setShowGoal(p=>!p); setSide(false); }}>
                      + Set a session goal
                    </button>
                }
                <div className="mem-sec" style={{ marginTop:14 }}>All 50 Fixes Active</div>
                <div style={{ fontSize:11.5, color:"rgba(255,255,255,0.22)", lineHeight:2 }}>
                  ✓ Anti-sycophancy &nbsp;·&nbsp; ✓ Math engine<br/>
                  ✓ Honest uncertainty &nbsp;·&nbsp; ✓ Crisis detection<br/>
                  ✓ Privacy guard &nbsp;·&nbsp; ✓ Repeat detection<br/>
                  ✓ Tone lock &nbsp;·&nbsp; ✓ Political balance<br/>
                  ✓ Cultural intelligence &nbsp;·&nbsp; ✓ Goal pinning<br/>
                  ✓ Session memory &nbsp;·&nbsp; ✓ Feedback learning<br/>
                  ✓ Date engine &nbsp;·&nbsp; ✓ {LANGUAGES.length} languages
                </div>
              </>
            )}
          </div>

          <div className="sb-footer">
            <div className="sf-item"><div className="sf-dot" style={{ background:"#22c55e" }}/><span className="sf-lbl">Online</span></div>
            <div className="sf-item"><div className="sf-dot" style={{ background:"#6366f1" }}/><span className="sf-lbl">Memory</span></div>
            <div className="sf-item"><div className="sf-dot" style={{ background:"#06b6d4" }}/><span className="sf-lbl">Math</span></div>
            <div className="sf-item"><div className="sf-dot" style={{ background:"#f87171" }}/><span className="sf-lbl">Crisis</span></div>
          </div>
        </aside>

        {/* ═══════════ MAIN ═══════════ */}
        <div className="main">
          {/* Header */}
          <div className="chat-header">
            <div className="ch-left">
              <button className="mob-menu-btn" onClick={() => setSide(o=>!o)}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
                </svg>
              </button>
              <div className="model-pill">
                <div className="mp-dot" />
                JPD.AI &nbsp;·&nbsp; {curLang.flag} {curLang.name}
              </div>
            </div>
            <div className="ch-badges">
              <span className="hb hb-amber">⚠ Honest</span>
              <span className="hb hb-indigo">🧠 Memory</span>
              <span className="hb hb-green">🔢 Math</span>
              <span className="hb hb-cyan">🌍 {LANGUAGES.length} langs</span>
              <span className="hb" style={{ background:"rgba(255,255,255,0.035)", border:"1px solid rgba(255,255,255,0.07)", color:"rgba(255,255,255,0.28)" }}>50/50 ✓</span>
            </div>
          </div>

          {/* Pinned goal bar */}
          {mem.pinnedGoal && (
            <div className="pinned-bar">
              <span className="pb-label">📌 Goal</span>
              <span style={{ flex:1, minWidth:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{mem.pinnedGoal}</span>
              <button className="pb-clear" onClick={clearGoal}>×</button>
            </div>
          )}

          {/* Messages */}
          <div className="msgs-wrap">
            <div className="msgs-inner">
              {messages.length === 0 ? (
                <div className="welcome">
                  <div className="w-gem-wrap">
                    <div className="w-ring2" />
                    <div className="w-ring" />
                    <div className="w-gem">J</div>
                  </div>
                  <div className="w-title">Hello, I'm JPD.AI</div>
                  <div className="w-sub">The world's most honest, multilingual AI — built to fix every flaw other AIs have. Never fakes confidence. Always remembers you.</div>
                  <div className="w-lang-line">🌍 Currently speaking: {curLang.flag} {curLang.native} · Switch in sidebar</div>
                  <div className="feat-grid">
                    {FEATURES.map((f,i) => (
                      <div key={i} className="feat-card">
                        <div className="fc-ico">{f.ico}</div>
                        <div className="fc-t">{f.t}</div>
                        <div className="fc-d">{f.d}</div>
                      </div>
                    ))}
                  </div>
                  <div className="suggestions">
                    {CHIPS.map(c => <button key={c} className="sug" onClick={() => send(c)}>{c}</button>)}
                  </div>
                </div>
              ) : (
                messages.map((m, i) => {
                  const isUser = m.role === "user";
                  const d = m.disp || {};
                  return (
                    <div key={i}>
                      <div className={`mrow ${isUser ? "user" : ""}`}>
                        <div className={`avatar ${isUser ? "av-user" : "av-ai"}`}>{isUser ? "U" : "J"}</div>
                        <div className={`bubble ${isUser ? "bub-user" : "bub-ai"} ${d.crisis ? "bub-crisis" : ""}`} dir={curLang.dir}>
                          {d.privacy && <div className="privacy-alert">🔒 Sensitive data detected — avoid sharing passwords or card numbers here.</div>}
                          {(d.imgs||[]).map((src,j) => <img key={j} src={src} className="msg-img" alt="" />)}
                          {d.math && (
                            <div className="math-chip">
                              <span style={{ fontSize:18 }}>🔢</span>
                              <div>
                                <div className="math-expr">{d.math.expr}</div>
                                <div className="math-res">= {d.math.result}</div>
                              </div>
                            </div>
                          )}
                          {d.repeat && <div className="repeat-tag">🔁 Adding depth to a previous answer</div>}
                          {d.text && (isUser
                            ? <div style={{ fontSize:13.5, lineHeight:1.8 }}>{d.text}</div>
                            : <Render text={d.text} />
                          )}
                        </div>
                      </div>
                      <div className={`msg-footer ${isUser ? "mrow user" : "mrow"}`} style={{ paddingLeft: isUser ? 0 : 40, paddingRight: isUser ? 40 : 0 }}>
                        <span className="msg-time">{d.ts}</span>
                        {!isUser && (
                          <>
                            <button className={`fb-btn ${feedback[i]==="like"?"active-like":""}`} onClick={() => giveFeedback(i,"like")} title="Helpful">👍</button>
                            <button className={`fb-btn ${feedback[i]==="dislike"?"active-dislike":""}`} onClick={() => giveFeedback(i,"dislike")} title="Not helpful">👎</button>
                            <button className={`copy-btn ${copiedIdx===i?"copied":""}`} onClick={() => copyMsg(d.text||"", i)} title="Copy">
                              {copiedIdx === i ? "✓ copied" : "⎘ copy"}
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })
              )}

              {loading && (
                <div className="typing-row">
                  <div className="avatar av-ai">J</div>
                  <div className="typing-bub"><div className="td"/><div className="td"/><div className="td"/></div>
                </div>
              )}

              {error && <div className="err-bar">{error}</div>}
              <div ref={bottomRef} />
            </div>
          </div>

          {/* Input area */}
          <div className="input-area">
            {images.length > 0 && (
              <div className="preview-strip">
                {images.map((img,i) => (
                  <div key={i} className="prev-wrap">
                    <img src={img.url} className="prev-img" alt="" />
                    <button className="prev-rm" onClick={() => setImages(p => p.filter((_,j) => j!==i))}>×</button>
                  </div>
                ))}
              </div>
            )}

            {recording && (
              <div className="rec-bar-wrap">
                <div className="rec-bar">
                  <div className="rec-dot" />
                  <span className="rec-text">Listening in {curLang.native}…</span>
                  <span className="rec-timer">{fmt(recSecs)}</span>
                  <button className="rec-stop-btn" onClick={stopRec}>
                    <svg width="9" height="9" viewBox="0 0 10 10" fill="currentColor"><rect width="10" height="10" rx="2"/></svg>
                  </button>
                </div>
              </div>
            )}

            {showGoal && !mem.pinnedGoal && (
              <div className="goal-pin-bar">
                <input className="goal-pin-inp" placeholder="What's your main goal for this session?" value={goalInput} onChange={e=>setGoalInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")pinGoal();}} autoFocus />
                <button className="goal-go-btn" onClick={pinGoal}>📌 Pin</button>
                <button className="goal-cancel-btn" onClick={()=>setShowGoal(false)}>Cancel</button>
              </div>
            )}

            <input ref={fileRef} type="file" accept="image/*" multiple style={{ display:"none" }} onChange={handleFiles} />

            <div className="iw">
              <button className="action-btn" onClick={() => fileRef.current?.click()} title="Upload image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>
                </svg>
              </button>

              <button className={`action-btn ${recording ? "recording" : ""}`} onClick={recording ? stopRec : startRec} title="Voice input">
                {recording
                  ? <svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>
                  : <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
                      <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                      <line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>
                    </svg>
                }
              </button>

              <button className="action-btn" title="Pin session goal" onClick={() => setShowGoal(p=>!p)}
                style={ mem.pinnedGoal ? { color:"#fbbf24", borderColor:"rgba(251,191,36,0.28)", background:"rgba(251,191,36,0.07)" } : {} }>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
                </svg>
              </button>

              <textarea
                ref={taRef}
                className="itxt"
                dir={curLang.dir}
                placeholder={recording ? "Transcribing voice…" : `Ask anything in ${curLang.native}…`}
                value={input}
                onChange={e => { setInput(e.target.value); resize(); }}
                onKeyDown={onKey}
                rows={1}
              />

              <button className="send-btn" onClick={() => send()} disabled={!canSend}>
                <svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
              </button>
            </div>

            <div className="input-hints">
              <span className="ih"><kbd className="kbd-hint">Enter</kbd> send</span>
              <span className="ih"><kbd className="kbd-hint">Shift+Enter</kbd> new line</span>
              <span className="ih">🎤 voice · {curLang.name}</span>
              <span className="ih">📷 image analysis</span>
              <span className="ih">📌 pin goal</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
