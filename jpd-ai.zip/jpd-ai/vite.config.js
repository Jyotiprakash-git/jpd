import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // If deploying to GitHub Pages at https://<username>.github.io/<repo-name>/
  // set base to '/<repo-name>/'
  // base: '/jpd-ai/',
})
